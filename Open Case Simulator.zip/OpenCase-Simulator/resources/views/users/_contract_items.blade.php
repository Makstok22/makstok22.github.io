<div class="contract-items col-md-10 col-md-offset-1">
    @for($i = 0; $i < 10; $i++)
        <div class="contract-item contract-item-empty col-md-5ths"></div>
    @endfor
</div>
